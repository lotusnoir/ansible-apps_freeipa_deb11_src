#
# Copyright (C) 2017  FreeIPA Contributors see COPYING for license
#
"""ipaplatform package
"""
NAME = None  # initialized by ipaplatform.osinfo
