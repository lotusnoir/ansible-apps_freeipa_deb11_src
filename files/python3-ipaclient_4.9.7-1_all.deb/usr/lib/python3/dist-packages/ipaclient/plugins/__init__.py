#
# Copyright (C) 2016  FreeIPA Contributors see COPYING for license
#

"""
Sub-package containing all client plugins.
"""
