#
# Copyright (C) 2017  FreeIPA Contributors see COPYING for license
#

"""
This module contains Debian specific platform files.
"""
